<div class="item-list-tabs no-ajax" id="subnav" role="navigation">
	<ul>
		<?php bp_get_options_nav( buddypress()->groups->current_group->slug . '_events' ); ?>
	</ul>
</div><!-- .item-list-tabs -->

