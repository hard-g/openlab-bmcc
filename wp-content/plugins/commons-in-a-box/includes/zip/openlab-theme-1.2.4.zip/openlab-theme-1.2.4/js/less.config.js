/**
 * Less js config
 */

var less = {
	env: "development",
	dumpLineNumbers: "mediaquery",
};
