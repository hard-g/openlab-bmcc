## Documentation: License

There are very specific terms for reproducing the documentation.
Please follow them carefully to avoid unnecessary legal issues and virtual head butting.

### GNU Free Documentation License

Permission is granted to copy, distribute and/or modify this
document under the terms of the GNU Free Documentation License,
Version 1.3 or any later version published by the Free Software
Foundation; with the Invariant Sections being just "Preamble", and "Credits",
with no Front-Cover Texts, and with no Back-Cover Texts.

A copy of the license is located here:
<a href="http://www.gnu.org/licenses/fdl.html" target="_blank">http://www.gnu.org/licenses/fdl.html</a>

### Exceptions

If you are a traditional (paper) or digital (news, blogs, etc) publisher and
require an exception to the license terms in order to distribute content
which includes the documentation of this project, contact us and we can
probably work something out.