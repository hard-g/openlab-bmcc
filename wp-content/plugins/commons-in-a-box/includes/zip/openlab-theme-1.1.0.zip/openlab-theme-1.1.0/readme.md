WordPress theme for Commons In A Box - OpenLab project

Not ready for use on production sites.
